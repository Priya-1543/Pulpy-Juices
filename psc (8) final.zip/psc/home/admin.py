

# Register your models here.
from django.contrib import admin
from home.models import product1,sales

admin.site.register(product1)
admin.site.register(sales)